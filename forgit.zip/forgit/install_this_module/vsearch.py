def searchforvowels(word, check="aeiou")->str :
        (word)=set(word).intersection(set(check))
        return (sorted(word))
